/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Population
 *    PROBLEM DEFINITION: Write a program that will predict the size of a population of organisms.
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 
 #include <iostream>
 #include <iomanip>
 #include <cmath>
 using namespace std;
 
 int main ()
 {
 	int start, day;
 	float ADPI, size;
 	
 	cout << "Please enter the starting size of organisms: ";
 	cin >> start;
 	
 	if (start >= 2)
 	{
 		cout << "Please enter the average daily population increase percentage: ";
 		cin >> ADPI;
 		
 		if(ADPI > 0)
 		{
 			ADPI = (ADPI / 100) + 1;
			cout << "Please enter the the number of days they will multiply: ";
 			cin >> day;
 			if (day >= 1)
 			{
 				for(int count=0; count < day; count++)
 				{
 					size = start * pow(ADPI,count);
 					cout << "The size of the oganism of day " << count << " is " << size << endl;
 					
				 }
			 }else
			 cout << "Please enter an valid day!" << endl; 
		 }else
		 cout << "Please enter an valid ADPI!" << endl;
	 }else 
	 cout << "Please enter an valid size!" << endl;
 	
 	return 0;
 }
