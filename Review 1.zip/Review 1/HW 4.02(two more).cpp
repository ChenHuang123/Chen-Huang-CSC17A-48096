/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Roman Numeral Converter
 *    PROBLEM DEFINITION: Write a program that asks the user to enter a number within the range of 1 through
    					  Use a switch statement to display the Roman numeral version of that number.
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 
 #include <iostream>
 using namespace std;
 
 int main () 
{
	int number;
	cout << "Please enter a number: ";
	cin >> number;
	
	if (number >= 1 && number <= 10)
	{	
		switch(number){
			
			case 1: cout << "The Roman numeral version of 1 is ��" << endl;
			break;
			
			case 2: cout << "The Roman numeral version of 2 is ��" << endl;
			break;	
			
			case 3: cout << "The Roman numeral version of 3 is ��" << endl;
			break;	
			
			case 4: cout << "The Roman numeral version of 4 is ��" << endl;
			break;	
			
			case 5: cout << "The Roman numeral version of 5 is ��" << endl;
			break;	
			
			case 6: cout << "The Roman numeral version of 6 is ��" << endl;
			break;	
			
			case 7: cout << "The Roman numeral version of 7 is ��" << endl;
			break;	
	
			case 8: cout << "The Roman numeral version of 8 is ��" << endl;
			break;
			
			case 9: cout << "The Roman numeral version of 9 is ��" << endl;
			break;
			
			case 10: cout << "The Roman numeral version of 10 is ��" << endl;
			break;
			
			default: cout << "please enter a valid number!" << endl;			
		}	
	}else 
	cout << "please enter a valid number!" << endl;
 	
	 return 0; 
 } 
