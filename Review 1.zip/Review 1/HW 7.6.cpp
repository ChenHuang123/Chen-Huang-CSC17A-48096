    /*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Rain or Shine
 *    PROBLEM DEFINITION: Write a program that stores this information in a
							3 �� 30 array of characters, where the row indicates the month (0 = June, 1 = July,
							2 = August) and the column indicates the day of the month
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 	#include <iostream>
	#include <fstream>   
 	using namespace std;
 	int main()
 	{
	 
	int month = 3;
    int day = 30;
    char weather[month][day];
    int sun, rain, cloudy;
    int totsun = 0;
    int totrain = 0;
    int totcloudy = 0;
    int lgrain = 0;
    ifstream inputFile;
    
    //Open file
    inputFile.open("RainOrShine.txt");
    if(!inputFile)
        cout<<"Error opening data file.";
    else{
        for(int row = 0;row<month;row++){
            for(int col = 0; col<day;col++){
                inputFile>>weather[row][col];
            }
        }
    }
    inputFile.close();
    
    //display the report
    cout<<"             Three month weather report             "<<endl;
    cout<<"----------------------------------------------------"<<endl;
    for(int row = 0; row<month; row++){
        sun = rain = cloudy = 0;
        for(int col = 0; col<day; col++){
            switch(weather[row][col]){
                case 'S' :sun++;
                break;
                case 'R' :rain++;
                break;
                case 'C' :cloudy++;
                break;
            }
        }
        
        //display the month number
        cout<<"For ";
        if(row ==0)
            cout <<"June"<<endl;
        else if(row == 1)
            cout <<"July"<<endl;
        else if(row == 2)
            cout<<"August"<<endl;
        
          cout<<"Rainy : "<<rain<<endl;
          cout<<"Sunny : "<<sun<<endl;
          cout<<"Cloudy : "<<cloudy<<endl;
        
        //calculate the totals for three month
        totsun +=sun;
        totrain+=rain;
        totcloudy+=cloudy;
        
        //Calculate the most rain day
        if(lgrain<rain)
            lgrain = row;
    }
    //Display the total
    cout<<"For the total:"<<endl;
    cout<<"Rainy : "<< totrain <<endl;
    cout<<"Sunny : "<< totrain <<endl;
    cout<<"cloudy : "<< totcloudy <<endl;
    
    //Display the largest rainy day for month
    cout <<"The month with the largest rainy days is ";
            if(lgrain == 0)
               cout<<"June."<<endl;
            else if (lgrain == 1)
                cout<<"July."<<endl;
            else if (lgrain == 2)
                cout<<"August."<<endl;
}


