    /*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Binary String Search
 *    PROBLEM DEFINITION: Modify the binarySearch function presented in this chapter so it searches an array
						 of strings instead of an array of int s.
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 
 #include <iostream>
#include <cstdlib>
#include <string>
#include <iomanip>
#include <fstream>
 using namespace std;
 int main() {
    
   
    void Sort(string [],int); 
	int Search(string,const string [],int);
    //declare variables
    const int SIZE = 20;
    string str;
    //String array
     string names[SIZE] = {"Collins, Bill", "Smith, Bart", "Allen, Jim",
                                "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
                                "Taylor, Terri", "Johnson, Jill",
                                "Allison, Jeff", "Looney, Joe", "Wolfe, Bill",
                                "James, Jean", "Weaver, Jim", "Pore, Bob",
                                "Rutherford, Greg", "Javens, Renee",
                                "Harrison, Rose", "Setzer, Cathy",
                                "Pike, Gordon", "Holland, Beth" } ;
    //Prompt user for string that they would like to search
    cout<<"Input a full name"<<endl;
    cin.ignore();
    getline(cin,str);
    //Sort the array
    Sort(names,SIZE);
    //Search the element
    int result= Search (str,names,SIZE);
    
    //Print the result 
    if(result==-1)
        cout<<"The name you searched is not in the array"<<endl;
    else
        cout<<"The name you searched is in the array"<<endl;
       
}
//mark sort
void Sort(string array[],int SIZE) {
    //mark the sort in the array
    for(int i=0;i<SIZE-1;i++) {
        for(int j=i+1;j<SIZE;j++) {
            if(array[i]>array[j]) {
                string temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
    }
}
int Search(string str,const string arr[],int SIZE) {
    int beg=0;
    int end=SIZE-1;
    int mid;
    do {
        mid=(beg+end)/2;
        if(str==arr[mid])
            return mid;
        else if(str<arr[mid]) {
            end=mid-1;
        }
        else {
            beg=mid+1;
        }
    }while(beg<=end);
    return 0;
}

