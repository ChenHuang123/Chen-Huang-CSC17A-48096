/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Celsius Temperature Table
 *    PROBLEM DEFINITION: Write a function
						  named celsius that accepts a Fahrenheit temperature as an argument. The function
						  should return the temperature, converted to Celsius
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 #include <iostream>
 #include <cstdlib>
 #include <ostream>
 
 using namespace std;
 
 int main() {
 
        int fahToCel(int);
        int fahT=0;
        int temp=0;
        //Display questions to gather input from the user.
        
		cout <<"\n\n\t\tCelsius Temperature Table"<< endl;
        cout<<"Enter the temperature in Fahrenheit to convert to Celsius: ";
        cin>>fahT;
        
		temp=fahToCel(fahT);//Function call
        cout<<fahT<<" Fahrenheit Degrees is "<<temp<<" Degrees Celsius"<<endl<<endl;
		//display result
        
		for(int i=0;i<21;i++){                                 
		// For loop to initiate a list of conversions 
            cout<<i<<" Degrees Fahrenheit is equivalent to "<<fahToCel(i)<<" Degrees Celsius"<<endl;
        }
        cout<<endl<<endl;
    }
    
   int fahToCel(int f){            
        int celsius=0;
        celsius=(0.5555) *(f-32);      
        return celsius;        
        }

