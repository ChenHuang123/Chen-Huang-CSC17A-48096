/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Miles per Gallon
 *    PROBLEM DEFINITION: 	A car holds 15 gallons of gasoline and can travel 375 miles before refueling. Write a
							program that calculates the number of miles per gallon the car gets. Display the result
							on the screen.
							Hint: Use the following formula to calculate miles per gallon (MPG):
							MPG  Miles Driven/Gallons of Gas Used
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 #include <iostream>
 using namespace std;
 
 int main ()
 {
 	int RPG, Miles, Gallons;
 	
	Miles = 375;
 	Gallons = 15;
    
    RPG = Miles / Gallons;
    
    cout << "The RPG of the car is " << RPG << endl;
    return 0;
 }
