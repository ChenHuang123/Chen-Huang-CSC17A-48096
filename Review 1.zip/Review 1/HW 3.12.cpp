/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Celsius to Fahrenheit
 *    PROBLEM DEFINITION: calculate the Fahrenheit
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
#include <iostream>
using namespace std;

int main ()
{
    int C;
    int F;
    cout << "Please enter the Celsius temperatures: "<< endl;
    
	cin >> C;

	F = 9/5 * C + 32;
    cout << "The Fahrenheit temperature is " << F <<"!"<< endl;
    
    
    return 0;
}



