/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Currency
 *    PROBLEM DEFINITION: calculate the Currency
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 #include <iostream>
 #include <iomanip>
 using namespace std;
 
 int main () 
 {
    float USD, yen, euros;
    
 	const float YEN_PER_DOLLAR = 98.93, EUROS_PER_DOLLAR = 0.74;
 	
	cout << "Please enter how many dollars you want to convert: " << endl;
 	
	cin >> USD;
	if (USD > 0)
	{
	yen = USD * YEN_PER_DOLLAR;
	euros = USD * EUROS_PER_DOLLAR;
	cout << endl;
	cout << setprecision(2) << showpoint << fixed << USD << " dollars equal to " << yen << " Japanese yen, equal to " << euros << " Euros" << endl;
	}else 
	{
	cout << "Please enter an valid amount of money larger that 0!" << endl;
	}
 	
 	
 	
 }
