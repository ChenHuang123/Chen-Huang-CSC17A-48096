/*
 *
 *            PROGRAMMER: Chen Huang    
 *         PROBLEM TITLE: Days in a Month
 *    PROBLEM DEFINITION: calculate the day of month
 *     SYSTEM - HARDWARE: Win7 64
 *            - SOFTWARE: NetBeans
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen
 *                                                                          
 * 
 *                                                              
 */
 #include <iostream>
 #include <iomanip>
 using namespace std;
 
 int main () 
 {
 	int month, year, indicater_one, indicater_two, indicater_three;
 	cout << "Please enter a month: ";
 	cin >> month;
	if (month <= 12 && month >= 1)
	{
		cout << "Please enter a year: ";
		cin >> year;
		if (year > 0)
		{
			if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12 )
			{
				cout << "31 Days" << endl;
		
		}else if(month = 2)
			{	
				indicater_one = year % 100;
			    indicater_two = year % 400;
			    indicater_three = year % 4;
			    if (indicater_one == 0 )
				{
					
					if(indicater_two == 0)
					{
					cout << "29 Days";
				}
				}else if(indicater_three == 0) 
				{
					cout << "29 Days";
				}else
				{
					cout << "28 Days";
				}
			}else if(month == 4 || month == 6 || month == 9 || month == 11)
			{
				cout << "30 days" << endl;
			}
		}else
		{	
		cout << "Please enter a valid year!" << endl;
		}
	}else 
 	{
	cout << "Please enter a valid month!" << endl; 
 	}
	return 0;
 }
